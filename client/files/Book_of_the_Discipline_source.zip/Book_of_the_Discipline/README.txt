# The Book of the Discipline: SuttaCentral edition #

Here are the files for the SuttaCentral edition of I.B. Horner's The Book of the Discipline. Included are:

* Book_of_the_Discipline.html: This is the Master file.

* bd.css: CSS for the above.

* bd.tex: TeX file for creating the above. To use as is requires the Skolar PE proprietary fonts. So best contact me if you want to recompile or make any changes.

* bd.jpeg: Cover for ebook. Not intended for print.

* Open Sanskrit fonts: These are derived from Open Sans, with extra glyphs for Sanskrit added using FontForge. Embedded in the EPUB. If they don't display well on you device, this is probably due to loss of hinting information when the fonts were modified. O well, you'll have to use your own fonts.

metadata.txt: XML DC metadata for ebook.
